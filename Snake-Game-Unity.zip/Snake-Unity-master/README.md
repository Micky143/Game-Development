# Snake-Unity
Snake game created using Unity engine.

Download APK Android file [here](https://github.com/dzduniak/Snake-Unity/files/1418958/snake.zip).

### Screenshot

![Screenshot](https://github.com/dzduniak/Snake-Unity/raw/master/Screenshot.png)
